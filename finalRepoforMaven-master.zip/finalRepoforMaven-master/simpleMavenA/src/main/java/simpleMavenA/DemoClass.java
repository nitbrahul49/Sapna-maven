package simpleMavenA;

public class DemoClass {

	
	public int addTwoNumbers(int a, int b)
	{
		return a+b;
	}
}
