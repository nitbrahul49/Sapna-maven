package com.codebind;

public class App {

		public int addNumbers(int a,int b)
		{
			return a+b;
		}
}
